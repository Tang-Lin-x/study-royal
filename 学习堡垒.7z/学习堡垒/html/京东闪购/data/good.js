var data = 
{
    "server_time": 1560757611,
    "goods_list": [
        {
            "goods_id": 80783298,
            "goods_name": "【21.76元抢200件，抢完恢复22.9元】3条装包邮 金号纯棉深色大格毛巾",
            "short_name": "欧莱雅（LOREAL）大眼甜心睫毛膏 8.6ml（欧莱雅彩妆 提拉卷翘 浓黑增密）",
            "thumb_url": "//img14.360buyimg.com/n7/jfs/t1/49186/31/4665/179073/5d2553f9E576fdaa0/989ab16ab2fd5fc8.jpg!q80",
            "hd_thumb_url": "http://omsproductionimg.yangkeduo.com/images/2018-06-11/88998463afb91e4c62058dab0a19ab2e.jpeg",
            "image_url": "//img14.360buyimg.com/n7/jfs/t1/49186/31/4665/179073/5d2553f9E576fdaa0/989ab16ab2fd5fc8.jpg!q80",
            "sales": 27000,
            "cnt": 27000,
            "group_price": 2176,
            "normal_price": 2990,
            "market_price": 8900,
            "event_type": 0,
            "customer_num": 2,
            "mall_id": 493592,
            "group": {
                "price": 2176,
                "customer_num": 2
            },
            "sales_tip": "已拼2.7万件",
            "link_url": "goods.html?goods_id=80783298",
            "hd_url": "http://omsproductionimg.yangkeduo.com/images/2017-10-02/5657c2cb8e15c73ad7048149199aea71.jpeg",
            "quantity": 71908,
            "activity_type": 3,
            "cat_id1": 9319,
            "goods_type": 1,
            "scores": {},
            "group_price_origin": 2176,
            "deposit_price": 2176,
            "paid_price": 4352
        },
        
    ]
}